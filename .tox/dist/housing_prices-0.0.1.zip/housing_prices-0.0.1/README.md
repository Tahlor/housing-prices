[![codecov](https://codecov.io/gh/Tahlor/housing-prices/branch/master/graph/badge.svg)](https://codecov.io/gh/Tahlor/housing-prices)
[![Build Status](https://travis-ci.org/Tahlor/housing-prices.svg?branch=master)](https://travis-ci.org/Tahlor/housing-prices)
[![Code Health](https://landscape.io/github/Tahlor/housing-prices/master/landscape.svg?style=flat)](https://landscape.io/github/Tahlor/housing-prices/master)


# housing-prices
Full API Documentation available at: [github pages](https://tahlor.github.io/housing-prices/html).  


