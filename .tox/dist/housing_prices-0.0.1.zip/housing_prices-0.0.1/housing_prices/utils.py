
def invert_dictionary(d):
    return dict( (v,k) for k in d for v in d[k] )


def reset_seed(SEED=42):
    import numpy as np
    import tensorflow as tf
    import random as rn
    import os
    os.environ['PYTHONHASHSEED'] = '0'
    np.random.seed(SEED)
    rn.seed(SEED)
    session_conf = tf.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    from keras import backend as K
    tf.set_random_seed(SEED)
    sess = tf.Session(graph=tf.get_default_graph(), config=session_conf)
    K.set_session(sess)

def checkEqual(L1, L2):
    return len(L1) == len(L2) and sorted(L1) == sorted(L2)
